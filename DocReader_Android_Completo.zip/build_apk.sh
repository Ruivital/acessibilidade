#!/usr/bin/env bash
set -e

echo "======================================================"
echo "    AUTOMAÇÃO DE COMPILAÇÃO ANDROID (LINUX MINT)"
echo "    DocReader"
echo "======================================================"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -f "$SCRIPT_DIR/build.gradle" ]; then
    PROJECT_DIR="$SCRIPT_DIR"
elif [ -d "$SCRIPT_DIR/DocReader" ] && [ -f "$SCRIPT_DIR/DocReader/build.gradle" ]; then
    PROJECT_DIR="$SCRIPT_DIR/DocReader"
else
    FOUND_DIR=$(find "$SCRIPT_DIR" -name "build.gradle" -exec dirname {} \; | head -n 1)
    if [ -n "$FOUND_DIR" ]; then
        PROJECT_DIR="$FOUND_DIR"
    else
        echo "[!] Erro: Não foi possível localizar a pasta do projeto Gradle."
        exit 1
    fi
fi

echo "[*] Pasta do projeto detetada em: $PROJECT_DIR"

if ! command -v javac &> /dev/null; then
    echo "[*] Java JDK não detetado. A instalar OpenJDK 17..."
    sudo apt update
    sudo apt install -y openjdk-17-jdk
else
    echo "[✔] Java JDK detetado."
fi

export JAVA_HOME="/usr/lib/jvm/java-17-openjdk-amd64"
export PATH="$JAVA_HOME/bin:$PATH"

cd "$PROJECT_DIR"

GRADLE_VERSION="8.2"
GRADLE_DIR="$SCRIPT_DIR/.gradle_local"
GRADLE_BIN="$GRADLE_DIR/gradle-$GRADLE_VERSION/bin/gradle"

if [ ! -f "$GRADLE_BIN" ]; then
    echo "[*] A descarregar o Gradle $GRADLE_VERSION..."
    mkdir -p "$GRADLE_DIR"
    GRADLE_ZIP="$GRADLE_DIR/gradle-$GRADLE_VERSION-bin.zip"
    if command -v wget &> /dev/null; then
        wget -q --show-progress "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -O "$GRADLE_ZIP"
    else
        curl -L --progress-bar "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$GRADLE_ZIP"
    fi
    unzip -q "$GRADLE_ZIP" -d "$GRADLE_DIR"
    rm -f "$GRADLE_ZIP"
else
    echo "[✔] Gradle $GRADLE_VERSION pronto."
fi

echo ""
echo "[*] A compilar o APK (assembleDebug)..."
"$GRADLE_BIN" assembleDebug --no-daemon

APK_SOURCE="$PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_SOURCE" ]; then
    DEST_APK="$SCRIPT_DIR/DocReader.apk"
    cp "$APK_SOURCE" "$DEST_APK"
    echo ""
    echo "======================================================"
    echo " [✔] COMPILAÇÃO CONCLUÍDA COM SUCESSO!"
    echo "     APK gerado em:"
    echo "     -> $DEST_APK"
    echo "======================================================"
else
    echo "[!] Erro: O APK gerado não foi encontrado."
    exit 1
fi
