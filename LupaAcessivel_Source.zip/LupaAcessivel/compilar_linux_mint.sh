#!/usr/bin/env bash
set -euo pipefail

COR_VERDE='\033[0;32m'
COR_AMARELO='\033[1;33m'
COR_VERMELHO='\033[0;31m'
COR_AZUL='\033[0;34m'
SEM_COR='\033[0m'

DIR_RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIR_SDK="${DIR_RAIZ}/.android_sdk"
DIR_TEMP="${DIR_RAIZ}/.tmp_build"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
GRADLE_VERSION="8.7"
GRADLE_ZIP_URL="https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"

limpar_temporarios() {
    if [ -d "${DIR_TEMP}" ]; then
        rm -rf "${DIR_TEMP}"
    fi
}
trap limpar_temporarios EXIT

log_info() { echo -e "${COR_AZUL}[INFO]${SEM_COR} $1"; }
log_ok()   { echo -e "${COR_VERDE}[OK]${SEM_COR} $1"; }
log_aviso(){ echo -e "${COR_AMARELO}[AVISO]${SEM_COR} $1"; }
log_erro() { echo -e "${COR_VERMELHO}[ERRO]${SEM_COR} $1" >&2; }

echo "=================================================================="
echo "   Compilador Automático - LupaAcessível (Linux Mint / Ubuntu)    "
echo "=================================================================="

if [ -f /etc/os-release ]; then
    . /etc/os-release
    log_info "Sistema detetado: ${PRETTY_NAME:-Linux}"
fi

PACOTES_FALTA=()
if ! command -v java >/dev/null 2>&1 || ! java -version 2>&1 | grep -q '"17\.'; then
    PACOTES_FALTA+=("openjdk-17-jdk")
fi
if ! command -v git >/dev/null 2>&1; then
    PACOTES_FALTA+=("git")
fi
if ! command -v wget >/dev/null 2>&1; then
    PACOTES_FALTA+=("wget")
fi
if ! command -v unzip >/dev/null 2>&1; then
    PACOTES_FALTA+=("unzip")
fi

if [ ${#PACOTES_FALTA[@]} -gt 0 ]; then
    log_info "A instalar dependências em falta via apt: ${PACOTES_FALTA[*]}"
    sudo apt-get update -qq || { log_erro "Falha ao atualizar apt."; exit 1; }
    sudo apt-get install -y -qq "${PACOTES_FALTA[@]}" || { log_erro "Falha ao instalar pacotes."; exit 1; }
    log_ok "Dependências instaladas."
else
    log_ok "JDK 17, Git, wget e unzip já estão instalados."
fi

JAVA_17_PATH=$(update-java-alternatives -l 2>/dev/null | grep "1.17" | awk '{print $3}' | head -n 1 || true)
if [ -n "${JAVA_17_PATH}" ] && [ -d "${JAVA_17_PATH}" ]; then
    export JAVA_HOME="${JAVA_17_PATH}"
    export PATH="${JAVA_HOME}/bin:${PATH}"
fi

mkdir -p "${DIR_TEMP}"
if [ ! -f "${DIR_SDK}/cmdline-tools/latest/bin/sdkmanager" ]; then
    log_info "A descarregar Android Command Line Tools..."
    mkdir -p "${DIR_SDK}/cmdline-tools"
    if ! wget -q --show-progress --tries=3 --timeout=30 -O "${DIR_TEMP}/cmdline-tools.zip" "${CMDLINE_TOOLS_URL}"; then
        log_erro "Falha ao descarregar Android Command Line Tools. Verifica a ligação à internet."
        exit 1
    fi
    unzip -q "${DIR_TEMP}/cmdline-tools.zip" -d "${DIR_TEMP}/extracted_tools"
    rm -rf "${DIR_SDK}/cmdline-tools/latest"
    mv "${DIR_TEMP}/extracted_tools/cmdline-tools" "${DIR_SDK}/cmdline-tools/latest"
    log_ok "Android Command Line Tools configuradas."
fi

export ANDROID_HOME="${DIR_SDK}"
export ANDROID_SDK_ROOT="${DIR_SDK}"
export PATH="${ANDROID_HOME}/cmdline-tools/latest/bin:${ANDROID_HOME}/platform-tools:${PATH}"

log_info "A aceitar licenças e instalar Android SDK (API 34)..."
set +o pipefail
yes | sdkmanager --sdk_root="${ANDROID_HOME}" --licenses >/dev/null 2>&1 || true
set -o pipefail

sdkmanager --sdk_root="${ANDROID_HOME}"     "platform-tools"     "platforms;android-34"     "build-tools;34.0.0" || {
        log_erro "Falha ao instalar componentes do SDK."
        exit 1
    }

echo "sdk.dir=${ANDROID_HOME}" > "${DIR_RAIZ}/local.properties"

if [ ! -f "${DIR_RAIZ}/gradle/wrapper/gradle-wrapper.jar" ]; then
    log_info "A descarregar Gradle ${GRADLE_VERSION} para gerar o wrapper..."
    if ! wget -q --show-progress --tries=3 --timeout=30 -O "${DIR_TEMP}/gradle.zip" "${GRADLE_ZIP_URL}"; then
        log_erro "Falha ao descarregar Gradle."
        exit 1
    fi
    unzip -q "${DIR_TEMP}/gradle.zip" -d "${DIR_TEMP}/gradle_dist"
    "${DIR_TEMP}/gradle_dist/gradle-${GRADLE_VERSION}/bin/gradle" wrapper --gradle-version "${GRADLE_VERSION}" --project-dir "${DIR_RAIZ}"
fi

chmod +x "${DIR_RAIZ}/gradlew"

log_info "A compilar LupaAcessível (assembleRelease)..."
cd "${DIR_RAIZ}"
./gradlew assembleRelease --no-daemon --stacktrace

APK_GERADO=$(find "${DIR_RAIZ}/app/build/outputs/apk/release" -name "*.apk" | head -n 1 || true)
if [ -z "${APK_GERADO}" ] || [ ! -f "${APK_GERADO}" ]; then
    log_erro "APK não encontrado após compilação."
    exit 1
fi

cp -f "${APK_GERADO}" "${DIR_RAIZ}/LupaAcessivel.apk"
chmod 755 "${DIR_RAIZ}/LupaAcessivel.apk"
limpar_temporarios

echo ""
echo "=================================================================="
log_ok "COMPILAÇÃO CONCLUÍDA! APK pronto em: ${DIR_RAIZ}/LupaAcessivel.apk"
echo "=================================================================="
