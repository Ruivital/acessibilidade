package pt.acessibilidade.lupafacil.model

import android.graphics.ColorMatrix

enum class VisionFilter(
    val displayName: String,
    val shortName: String,
    val description: String
) {
    NORMAL(
        displayName = "Normal (Cores Naturais)",
        shortName = "Normal",
        description = "Imagem original sem filtros de cor."
    ),
    HIGH_CONTRAST_BW(
        displayName = "Alto Contraste (Branco no Preto)",
        shortName = "Branco/Preto",
        description = "Converte para preto e branco de alto contraste."
    ),
    INVERTED(
        displayName = "Cores Invertidas (Negativo)",
        shortName = "Invertido",
        description = "Inverte as cores para reduzir encandeamento em fundos brancos."
    ),
    YELLOW_ON_BLACK(
        displayName = "Amarelo sobre Preto",
        shortName = "Amarelo/Preto",
        description = "Alto contraste amarelo brilhante sobre fundo escuro para baixa visão."
    ),
    PROTANOPIA(
        displayName = "Correção Protanopia (Vermelho)",
        shortName = "Protanopia",
        description = "Realça diferenças entre tons vermelhos e verdes."
    ),
    DEUTERANOPIA(
        displayName = "Correção Deuteranopia (Verde)",
        shortName = "Deuteranopia",
        description = "Aumenta a separação cromática para dificuldade no espectro verde."
    ),
    TRITANOPIA(
        displayName = "Correção Tritanopia (Azul/Amarelo)",
        shortName = "Tritanopia",
        description = "Ajusta o espectro azul-amarelo para melhor distinção."
    );

    fun toAndroidColorMatrix(): ColorMatrix {
        return when (this) {
            NORMAL -> ColorMatrix()

            HIGH_CONTRAST_BW -> {
                val contrast = 2.6f
                val translate = (-0.5f * contrast + 0.5f) * 255f
                ColorMatrix(
                    floatArrayOf(
                        0.33f * contrast, 0.59f * contrast, 0.08f * contrast, 0f, translate,
                        0.33f * contrast, 0.59f * contrast, 0.08f * contrast, 0f, translate,
                        0.33f * contrast, 0.59f * contrast, 0.08f * contrast, 0f, translate,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            }

            INVERTED -> ColorMatrix(
                floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            YELLOW_ON_BLACK -> {
                val c = 2.4f
                val t = (-0.5f * c + 0.5f) * 255f
                ColorMatrix(
                    floatArrayOf(
                        -0.33f * c, -0.59f * c, -0.08f * c, 0f, 255f - t,
                        -0.30f * c, -0.53f * c, -0.07f * c, 0f, 230f - t,
                        0f, 0f, 0f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            }

            PROTANOPIA -> {
                ColorMatrix(
                    floatArrayOf(
                        0.567f, 0.433f, 0.000f, 0f, 0f,
                        0.558f, 0.442f, 0.000f, 0f, 0f,
                        0.000f, 0.242f, 0.758f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            }

            DEUTERANOPIA -> {
                ColorMatrix(
                    floatArrayOf(
                        0.625f, 0.375f, 0.000f, 0f, 0f,
                        0.700f, 0.300f, 0.000f, 0f, 0f,
                        0.000f, 0.300f, 0.700f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            }

            TRITANOPIA -> {
                ColorMatrix(
                    floatArrayOf(
                        0.950f, 0.050f, 0.000f, 0f, 0f,
                        0.000f, 0.433f, 0.567f, 0f, 0f,
                        0.000f, 0.475f, 0.525f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            }
        }
    }

    fun toComposeColorMatrix(): androidx.compose.ui.graphics.ColorMatrix {
        return androidx.compose.ui.graphics.ColorMatrix(toAndroidColorMatrix().array)
    }
}
