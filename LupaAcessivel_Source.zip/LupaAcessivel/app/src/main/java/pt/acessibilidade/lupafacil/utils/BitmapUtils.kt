package pt.acessibilidade.lupafacil.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.camera.core.ImageProxy

object BitmapUtils {
    fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
        return try {
            val buffer = image.planes[0].buffer
            buffer.rewind()
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)

            val rawBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val rotationDegrees = image.imageInfo.rotationDegrees

            if (rotationDegrees == 0) {
                rawBitmap
            } else {
                val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
                val rotated = Bitmap.createBitmap(
                    rawBitmap,
                    0,
                    0,
                    rawBitmap.width,
                    rawBitmap.height,
                    matrix,
                    true
                )
                if (rotated != rawBitmap) {
                    rawBitmap.recycle()
                }
                rotated
            }
        } catch (e: Exception) {
            null
        }
    }
}
