package pt.acessibilidade.lupafacil.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val HighContrastBlack = Color(0xFF0A0A0A)
val HighContrastSurface = Color(0xFF161616)
val HighContrastYellow = Color(0xFFFFD600)
val HighContrastWhite = Color(0xFFFFFFFF)
val HighContrastBorder = Color(0xFF424242)
val AlertRed = Color(0xFFFF5252)

private val AccessibleDarkColorScheme = darkColorScheme(
    primary = HighContrastYellow,
    onPrimary = HighContrastBlack,
    secondary = HighContrastWhite,
    onSecondary = HighContrastBlack,
    background = HighContrastBlack,
    onBackground = HighContrastWhite,
    surface = HighContrastSurface,
    onSurface = HighContrastWhite,
    outline = HighContrastYellow
)

private val AccessibleTypography = Typography(
    titleLarge = TextStyle(
        fontWeight = FontWeight.ExtraBold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 18.sp,
        lineHeight = 26.sp
    ),
    labelLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        lineHeight = 20.sp
    )
)

@Composable
fun LupaAcessivelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AccessibleDarkColorScheme,
        typography = AccessibleTypography,
        content = content
    )
}
