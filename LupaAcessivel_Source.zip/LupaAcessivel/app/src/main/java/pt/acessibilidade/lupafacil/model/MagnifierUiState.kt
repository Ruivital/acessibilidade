package pt.acessibilidade.lupafacil.model

import android.graphics.Bitmap

data class MagnifierUiState(
    val zoomRatio: Float = 1.0f,
    val minZoom: Float = 1.0f,
    val maxZoom: Float = 8.0f,
    val isFrozen: Boolean = false,
    val frozenBitmap: Bitmap? = null,
    val isFlashOn: Boolean = false,
    val hasFlashUnit: Boolean = false,
    val supportsTorchStrength: Boolean = false,
    val torchStrengthLevel: Int = 1,
    val maxTorchStrengthLevel: Int = 1,
    val activeFilter: VisionFilter = VisionFilter.NORMAL,
    val isProcessingOcr: Boolean = false,
    val recognizedText: String? = null,
    val showOcrSheet: Boolean = false,
    val isSpeaking: Boolean = false,
    val showFilterSheet: Boolean = false,
    val statusAnnouncement: String = ""
)
