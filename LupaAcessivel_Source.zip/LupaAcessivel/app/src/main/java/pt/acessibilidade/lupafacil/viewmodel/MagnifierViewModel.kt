package pt.acessibilidade.lupafacil.viewmodel

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pt.acessibilidade.lupafacil.model.MagnifierUiState
import pt.acessibilidade.lupafacil.model.VisionFilter
import pt.acessibilidade.lupafacil.utils.BitmapUtils
import pt.acessibilidade.lupafacil.utils.OfflineOcrAndTtsManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MagnifierViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(MagnifierUiState())
    val uiState: StateFlow<MagnifierUiState> = _uiState.asStateFlow()

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var currentSurfaceProvider: Preview.SurfaceProvider? = null
    private var currentLifecycleOwner: LifecycleOwner? = null
    private var backCameraId: String? = null

    private val ocrAndTtsManager = OfflineOcrAndTtsManager(application) { speaking ->
        _uiState.update { it.copy(isSpeaking = speaking) }
    }

    init {
        inspectHardwareFlashCapabilities(application)
    }

    private fun inspectHardwareFlashCapabilities(context: Context) {
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            for (id in cameraManager.cameraIdList) {
                val chars = cameraManager.getCameraCharacteristics(id)
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_BACK) {
                    backCameraId = id
                    val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    var supportsStrength = false
                    var maxLevel = 1

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && hasFlash) {
                        val maxStrength = chars.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                        if (maxStrength > 1) {
                            supportsStrength = true
                            maxLevel = maxStrength
                        }
                    }

                    _uiState.update {
                        it.copy(
                            hasFlashUnit = hasFlash,
                            supportsTorchStrength = supportsStrength,
                            maxTorchStrengthLevel = maxLevel,
                            torchStrengthLevel = (maxLevel / 2).coerceAtLeast(1)
                        )
                    }
                    break
                }
            }
        } catch (_: Exception) {
        }
    }

    fun bindCamera(lifecycleOwner: LifecycleOwner, surfaceProvider: Preview.SurfaceProvider) {
        currentLifecycleOwner = lifecycleOwner
        currentSurfaceProvider = surfaceProvider

        // Se estiver no modo congelado, NÃO religar o sensor da câmara (poupança extrema de bateria)
        if (_uiState.value.isFrozen) return

        val context = getApplication<Application>()
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

        cameraProviderFuture.addListener({
            try {
                val provider = cameraProviderFuture.get()
                cameraProvider = provider

                val preview = Preview.Builder().build().apply {
                    setSurfaceProvider(surfaceProvider)
                }

                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                imageCapture = capture

                provider.unbindAll()
                val boundCamera = provider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    capture
                )
                camera = boundCamera

                val zoomState = boundCamera.cameraInfo.zoomState.value
                val minZ = zoomState?.minZoomRatio ?: 1.0f
                val maxZ = (zoomState?.maxZoomRatio ?: 8.0f).coerceAtMost(10.0f)
                val targetZoom = _uiState.value.zoomRatio.coerceIn(minZ, maxZ)

                boundCamera.cameraControl.setZoomRatio(targetZoom)

                _uiState.update {
                    it.copy(
                        minZoom = minZ,
                        maxZoom = maxZ,
                        zoomRatio = targetZoom
                    )
                }

                if (_uiState.value.isFlashOn) {
                    applyTorchState(true, _uiState.value.torchStrengthLevel)
                }
            } catch (e: Exception) {
                announce("Erro ao iniciar a câmara: ${e.localizedMessage ?: "desconhecido"}")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun setZoomRatio(newZoom: Float) {
        val state = _uiState.value
        val clamped = newZoom.coerceIn(state.minZoom, state.maxZoom)
        _uiState.update { it.copy(zoomRatio = clamped) }

        if (!state.isFrozen) {
            camera?.cameraControl?.setZoomRatio(clamped)
        }
    }

    fun stepZoom(delta: Float) {
        setZoomRatio(_uiState.value.zoomRatio + delta)
    }

    fun toggleTorch() {
        val state = _uiState.value
        if (!state.hasFlashUnit || state.isFrozen) return
        val nextState = !state.isFlashOn
        applyTorchState(nextState, state.torchStrengthLevel)
        _uiState.update { it.copy(isFlashOn = nextState) }
        announce(if (nextState) "Lanterna ligada" else "Lanterna desligada")
    }

    fun setTorchStrength(level: Int) {
        val state = _uiState.value
        val clamped = level.coerceIn(1, state.maxTorchStrengthLevel)
        _uiState.update { it.copy(torchStrengthLevel = clamped, isFlashOn = true) }
        if (!state.isFrozen) {
            applyTorchState(true, clamped)
        }
    }

    private fun applyTorchState(enabled: Boolean, strengthLevel: Int) {
        try {
            if (!enabled) {
                camera?.cameraControl?.enableTorch(false)
                return
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                _uiState.value.supportsTorchStrength &&
                backCameraId != null
            ) {
                val cameraManager = getApplication<Application>()
                    .getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cameraManager.turnOnTorchWithStrengthLevel(backCameraId!!, strengthLevel)
            } else {
                camera?.cameraControl?.enableTorch(true)
            }
        } catch (_: Exception) {
            camera?.cameraControl?.enableTorch(enabled)
        }
    }

    fun toggleFreeze() {
        val state = _uiState.value
        if (state.isFrozen) {
            unfreeze()
        } else {
            freezeCurrentFrame()
        }
    }

    private fun freezeCurrentFrame() {
        val capture = imageCapture ?: return
        val context = getApplication<Application>()

        capture.takePicture(
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    viewModelScope.launch {
                        val bitmap = withContext(Dispatchers.Default) {
                            BitmapUtils.imageProxyToBitmap(image)
                        }
                        image.close()

                        if (bitmap != null) {
                            // OTIMIZAÇÃO EXTREMA DE BATERIA:
                            // Desliga lanterna e desvincula hardware da câmara imediatamente
                            applyTorchState(false, 1)
                            cameraProvider?.unbindAll()
                            camera = null

                            _uiState.update {
                                it.copy(
                                    isFrozen = true,
                                    frozenBitmap = bitmap,
                                    isFlashOn = false,
                                    statusAnnouncement = "Imagem congelada. Câmara desligada para poupar bateria."
                                )
                            }
                        } else {
                            announce("Não foi possível congelar a imagem.")
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    announce("Falha ao capturar imagem para congelar.")
                }
            }
        )
    }

    private fun unfreeze() {
        ocrAndTtsManager.stopSpeaking()
        val oldBitmap = _uiState.value.frozenBitmap

        _uiState.update {
            it.copy(
                isFrozen = false,
                frozenBitmap = null,
                recognizedText = null,
                showOcrSheet = false,
                zoomRatio = 1.0f,
                statusAnnouncement = "Modo ao vivo reativado."
            )
        }

        if (oldBitmap != null && !oldBitmap.isRecycled) {
            oldBitmap.recycle()
        }

        val owner = currentLifecycleOwner
        val surface = currentSurfaceProvider
        if (owner != null && surface != null) {
            bindCamera(owner, surface)
        }
    }

    fun setFilter(filter: VisionFilter) {
        _uiState.update {
            it.copy(
                activeFilter = filter,
                showFilterSheet = false,
                statusAnnouncement = "Filtro aplicado: ${filter.displayName}"
            )
        }
    }

    fun toggleFilterSheet(show: Boolean) {
        _uiState.update { it.copy(showFilterSheet = show) }
    }

    fun runOfflineOcr() {
        val state = _uiState.value
        if (state.isProcessingOcr) return

        if (state.isFrozen && state.frozenBitmap != null) {
            processBitmapOcr(state.frozenBitmap)
            return
        }

        val capture = imageCapture ?: return
        val context = getApplication<Application>()
        _uiState.update { it.copy(isProcessingOcr = true) }

        capture.takePicture(
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    viewModelScope.launch {
                        val bitmap = withContext(Dispatchers.Default) {
                            BitmapUtils.imageProxyToBitmap(image)
                        }
                        image.close()

                        if (bitmap != null) {
                            applyTorchState(false, 1)
                            cameraProvider?.unbindAll()
                            camera = null

                            _uiState.update {
                                it.copy(
                                    isFrozen = true,
                                    frozenBitmap = bitmap,
                                    isFlashOn = false
                                )
                            }
                            processBitmapOcr(bitmap)
                        } else {
                            _uiState.update { it.copy(isProcessingOcr = false) }
                            announce("Falha ao capturar imagem para leitura.")
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    _uiState.update { it.copy(isProcessingOcr = false) }
                    announce("Erro na câmara ao tentar ler texto.")
                }
            }
        )
    }

    private fun processBitmapOcr(bitmap: Bitmap) {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessingOcr = true) }
            val result = ocrAndTtsManager.recognizeTextFromBitmap(bitmap)

            result.fold(
                onSuccess = { text ->
                    val finalMessage = text.ifBlank {
                        "Nenhum texto legível foi detetado nesta imagem."
                    }
                    _uiState.update {
                        it.copy(
                            isProcessingOcr = false,
                            recognizedText = finalMessage,
                            showOcrSheet = true
                        )
                    }
                    if (text.isNotBlank()) {
                        ocrAndTtsManager.speak(text)
                    } else {
                        announce(finalMessage)
                    }
                },
                onFailure = {
                    _uiState.update { it.copy(isProcessingOcr = false) }
                    announce("Erro ao processar leitura offline.")
                }
            )
        }
    }

    fun toggleSpeech() {
        val text = _uiState.value.recognizedText ?: return
        if (_uiState.value.isSpeaking) {
            ocrAndTtsManager.stopSpeaking()
        } else {
            ocrAndTtsManager.speak(text)
        }
    }

    fun dismissOcrSheet() {
        ocrAndTtsManager.stopSpeaking()
        _uiState.update { it.copy(showOcrSheet = false) }
    }

    fun copyRecognizedTextToClipboard() {
        val text = _uiState.value.recognizedText ?: return
        val context = getApplication<Application>()
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Texto LupaAcessível", text))
        announce("Texto copiado para a área de transferência.")
    }

    fun saveRecognizedTextLocally() {
        val text = _uiState.value.recognizedText ?: return
        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val filename = "LupaAcessivel_$timestamp.txt"

                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/LupaAcessivel")
                    }
                }

                val uri = context.contentResolver.insert(MediaStore.Files.getContentUri("external"), values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(text.toByteArray(Charsets.UTF_8))
                    }
                    announce("Texto guardado localmente em Documentos.")
                } else {
                    announce("Não foi possível guardar o ficheiro.")
                }
            } catch (_: Exception) {
                announce("Erro ao guardar ficheiro localmente.")
            }
        }
    }

    private fun announce(message: String) {
        _uiState.update { it.copy(statusAnnouncement = message) }
    }

    override fun onCleared() {
        super.onCleared()
        ocrAndTtsManager.release()
        _uiState.value.frozenBitmap?.let {
            if (!it.isRecycled) it.recycle()
        }
    }
}
