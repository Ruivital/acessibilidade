package pt.acessibilidade.lupafacil

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import pt.acessibilidade.lupafacil.ui.MagnifierScreen
import pt.acessibilidade.lupafacil.ui.theme.LupaAcessivelTheme
import pt.acessibilidade.lupafacil.viewmodel.MagnifierViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MagnifierViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            LupaAcessivelTheme {
                var hasCameraPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.CAMERA
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { granted ->
                    hasCameraPermission = granted
                }

                MagnifierScreen(
                    viewModel = viewModel,
                    hasCameraPermission = hasCameraPermission,
                    onRequestCameraPermission = {
                        permissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                )
            }
        }
    }

    // Ergonomia: Usar botões físicos de Volume (+ / -) para controlar o Zoom da Lupa
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                viewModel.stepZoom(0.5f)
                true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                viewModel.stepZoom(-0.5f)
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }
}
