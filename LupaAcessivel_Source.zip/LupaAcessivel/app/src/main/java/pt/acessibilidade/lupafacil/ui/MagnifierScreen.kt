package pt.acessibilidade.lupafacil.ui

import android.graphics.Paint
import android.view.View
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import pt.acessibilidade.lupafacil.model.MagnifierUiState
import pt.acessibilidade.lupafacil.model.VisionFilter
import pt.acessibilidade.lupafacil.ui.theme.AlertRed
import pt.acessibilidade.lupafacil.ui.theme.HighContrastBlack
import pt.acessibilidade.lupafacil.ui.theme.HighContrastSurface
import pt.acessibilidade.lupafacil.ui.theme.HighContrastWhite
import pt.acessibilidade.lupafacil.ui.theme.HighContrastYellow
import pt.acessibilidade.lupafacil.viewmodel.MagnifierViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MagnifierScreen(
    viewModel: MagnifierViewModel,
    hasCameraPermission: Boolean,
    onRequestCameraPermission: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val haptics = LocalHapticFeedback.current

    if (!hasCameraPermission) {
        PermissionRequiredScreen(onRequestCameraPermission)
        return
    }

    Scaffold(
        containerColor = HighContrastBlack,
        topBar = {
            AccessibleTopBar(
                uiState = uiState,
                onToggleFlash = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.toggleTorch()
                },
                onTorchStrengthChange = { viewModel.setTorchStrength(it) }
            )
        },
        bottomBar = {
            AccessibleBottomControls(
                uiState = uiState,
                onZoomChange = { viewModel.setZoomRatio(it) },
                onStepZoom = { delta ->
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    viewModel.stepZoom(delta)
                },
                onOpenFilters = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.toggleFilterSheet(true)
                },
                onToggleFreeze = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.toggleFreeze()
                },
                onRunOcr = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.runOfflineOcr()
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(HighContrastBlack)
        ) {
            if (uiState.isFrozen && uiState.frozenBitmap != null) {
                FrozenBitmapViewport(
                    bitmap = uiState.frozenBitmap!!,
                    activeFilter = uiState.activeFilter,
                    externalZoom = uiState.zoomRatio,
                    onZoomChange = { viewModel.setZoomRatio(it) },
                    onDoubleTapUnfreeze = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        viewModel.toggleFreeze()
                    }
                )
            } else {
                LiveCameraViewport(
                    viewModel = viewModel,
                    activeFilter = uiState.activeFilter,
                    currentZoom = uiState.zoomRatio,
                    onPinchZoom = { viewModel.setZoomRatio(it) },
                    onDoubleTapFreeze = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        viewModel.toggleFreeze()
                    }
                )
            }

            if (uiState.isFrozen) {
                Surface(
                    color = HighContrastYellow,
                    shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .semantics {
                            liveRegion = LiveRegionMode.Polite
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BatteryChargingFull,
                            contentDescription = null,
                            tint = HighContrastBlack,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "CONGELADO • CÂMARA DESLIGADA",
                            color = HighContrastBlack,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            if (uiState.isProcessingOcr) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.75f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(
                            color = HighContrastYellow,
                            strokeWidth = 6.dp,
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = "A ler texto localmente...",
                            color = HighContrastWhite,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }

            if (uiState.statusAnnouncement.isNotBlank()) {
                Text(
                    text = uiState.statusAnnouncement,
                    modifier = Modifier
                        .size(1.dp)
                        .semantics { liveRegion = LiveRegionMode.Assertive },
                    color = Color.Transparent
                )
            }
        }
    }

    if (uiState.showFilterSheet) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.toggleFilterSheet(false) },
            containerColor = HighContrastSurface,
            contentColor = HighContrastWhite
        ) {
            FilterSelectionSheet(
                selectedFilter = uiState.activeFilter,
                onSelectFilter = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.setFilter(it)
                }
            )
        }
    }

    if (uiState.showOcrSheet && uiState.recognizedText != null) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.dismissOcrSheet() },
            containerColor = HighContrastSurface,
            contentColor = HighContrastWhite
        ) {
            OcrResultSheet(
                text = uiState.recognizedText!!,
                isSpeaking = uiState.isSpeaking,
                onToggleSpeak = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.toggleSpeech()
                },
                onCopyText = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.copyRecognizedTextToClipboard()
                },
                onSaveText = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.saveRecognizedTextLocally()
                },
                onClose = { viewModel.dismissOcrSheet() }
            )
        }
    }
}

@Composable
private fun LiveCameraViewport(
    viewModel: MagnifierViewModel,
    activeFilter: VisionFilter,
    currentZoom: Float,
    onPinchZoom: (Float) -> Unit,
    onDoubleTapFreeze: () -> Unit
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestZoom by rememberUpdatedState(currentZoom)

    val filterPaint = remember(activeFilter) {
        Paint().apply {
            if (activeFilter != VisionFilter.NORMAL) {
                colorFilter = android.graphics.ColorMatrixColorFilter(
                    activeFilter.toAndroidColorMatrix()
                )
            }
        }
    }

    AndroidView(
        factory = { ctx ->
            PreviewView(ctx).apply {
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                scaleType = PreviewView.ScaleType.FILL_CENTER
                viewModel.bindCamera(lifecycleOwner, surfaceProvider)
            }
        },
        update = { previewView ->
            if (activeFilter == VisionFilter.NORMAL) {
                previewView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            } else {
                previewView.setLayerType(View.LAYER_TYPE_HARDWARE, filterPaint)
            }
        },
        modifier = Modifier
            .fillMaxSize()
            .semantics {
                contentDescription = "Visor da lupa ao vivo. Dê dois toques rápidos para congelar a imagem."
            }
            .pointerInput(Unit) {
                detectTransformGestures { _, _, zoomChange, _ ->
                    if (zoomChange != 1f) {
                        onPinchZoom(latestZoom * zoomChange)
                    }
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { onDoubleTapFreeze() }
                )
            }
    )
}

@Composable
private fun FrozenBitmapViewport(
    bitmap: android.graphics.Bitmap,
    activeFilter: VisionFilter,
    externalZoom: Float,
    onZoomChange: (Float) -> Unit,
    onDoubleTapUnfreeze: () -> Unit
) {
    var panOffset by remember(bitmap) { mutableStateOf(Offset.Zero) }
    val latestZoom by rememberUpdatedState(externalZoom)

    val composeColorFilter = remember(activeFilter) {
        if (activeFilter == VisionFilter.NORMAL) null
        else ColorFilter.colorMatrix(activeFilter.toComposeColorMatrix())
    }

    val imageBitmap = remember(bitmap) { bitmap.asImageBitmap() }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .semantics {
                contentDescription = "Imagem congelada. Arraste com um dedo para mover e use dois dedos para ampliar. Dê dois toques para voltar ao vivo."
            }
            .pointerInput(bitmap) {
                detectTransformGestures { _, pan, zoomChange, _ ->
                    val newZoom = (latestZoom * zoomChange).coerceIn(1.0f, 8.0f)
                    onZoomChange(newZoom)
                    if (newZoom > 1.0f) {
                        panOffset += pan
                    } else {
                        panOffset = Offset.Zero
                    }
                }
            }
            .pointerInput(bitmap) {
                detectTapGestures(
                    onDoubleTap = { onDoubleTapUnfreeze() }
                )
            }
    ) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        val imgWidth = imageBitmap.width.toFloat()
        val imgHeight = imageBitmap.height.toFloat()

        val scale = maxOf(canvasWidth / imgWidth, canvasHeight / imgHeight)
        val drawWidth = (imgWidth * scale).roundToInt()
        val drawHeight = (imgHeight * scale).roundToInt()
        val left = ((canvasWidth - drawWidth) / 2f).roundToInt()
        val top = ((canvasHeight - drawHeight) / 2f).roundToInt()

        withTransform({
            translate(left = panOffset.x, top = panOffset.y)
            scale(scaleX = externalZoom, scaleY = externalZoom, pivot = center)
        }) {
            drawImage(
                image = imageBitmap,
                dstOffset = IntOffset(left, top),
                dstSize = IntSize(drawWidth, drawHeight),
                colorFilter = composeColorFilter
            )
        }
    }
}

@Composable
private fun AccessibleTopBar(
    uiState: MagnifierUiState,
    onToggleFlash: () -> Unit,
    onTorchStrengthChange: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(HighContrastBlack)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.semantics {
                    contentDescription = "Modo 100% offline ativo. Sem ligação à internet."
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = HighContrastYellow,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = "LupaAcessível",
                    color = HighContrastWhite,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )
            }

            if (uiState.hasFlashUnit) {
                val enabled = !uiState.isFrozen
                Button(
                    onClick = onToggleFlash,
                    enabled = enabled,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.isFlashOn) HighContrastYellow else HighContrastSurface,
                        contentColor = if (uiState.isFlashOn) HighContrastBlack else HighContrastWhite,
                        disabledContainerColor = Color(0xFF222222),
                        disabledContentColor = Color(0xFF777777)
                    ),
                    border = BorderStroke(2.dp, if (enabled) HighContrastYellow else Color(0xFF444444)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .defaultMinSize(minWidth = 128.dp, minHeight = 52.dp)
                        .semantics {
                            stateDescription = if (uiState.isFlashOn) "Ligada" else "Desligada"
                        }
                ) {
                    Icon(
                        imageVector = if (uiState.isFlashOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (uiState.isFlashOn) "LUZ ON" else "LUZ OFF",
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        if (uiState.isFlashOn && uiState.supportsTorchStrength && !uiState.isFrozen) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Brilho LED:",
                    color = HighContrastYellow,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Slider(
                    value = uiState.torchStrengthLevel.toFloat(),
                    onValueChange = { onTorchStrengthChange(it.roundToInt()) },
                    valueRange = 1f..uiState.maxTorchStrengthLevel.toFloat(),
                    steps = (uiState.maxTorchStrengthLevel - 2).coerceAtLeast(0),
                    colors = SliderDefaults.colors(
                        thumbColor = HighContrastYellow,
                        activeTrackColor = HighContrastYellow,
                        inactiveTrackColor = HighContrastSurface
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .semantics {
                            contentDescription = "Intensidade da lanterna, nível ${uiState.torchStrengthLevel} de ${uiState.maxTorchStrengthLevel}"
                        }
                )
            }
        }
    }
}

@Composable
private fun AccessibleBottomControls(
    uiState: MagnifierUiState,
    onZoomChange: (Float) -> Unit,
    onStepZoom: (Float) -> Unit,
    onOpenFilters: () -> Unit,
    onToggleFreeze: () -> Unit,
    onRunOcr: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(HighContrastBlack)
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FilledIconButton(
                onClick = { onStepZoom(-0.5f) },
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = HighContrastSurface,
                    contentColor = HighContrastYellow
                ),
                modifier = Modifier
                    .size(56.dp)
                    .border(2.dp, HighContrastYellow, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Remove,
                    contentDescription = "Diminuir ampliação",
                    modifier = Modifier.size(30.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = String.format("%.1fx", uiState.zoomRatio),
                    color = HighContrastYellow,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    modifier = Modifier.semantics {
                        contentDescription = "Ampliação atual: ${String.format("%.1f", uiState.zoomRatio)} vezes"
                    }
                )
                Slider(
                    value = uiState.zoomRatio,
                    onValueChange = onZoomChange,
                    valueRange = uiState.minZoom..uiState.maxZoom,
                    colors = SliderDefaults.colors(
                        thumbColor = HighContrastYellow,
                        activeTrackColor = HighContrastYellow,
                        inactiveTrackColor = HighContrastSurface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .semantics {
                            contentDescription = "Controlo deslizante de ampliação"
                        }
                )
            }

            FilledIconButton(
                onClick = { onStepZoom(0.5f) },
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = HighContrastSurface,
                    contentColor = HighContrastYellow
                ),
                modifier = Modifier
                    .size(56.dp)
                    .border(2.dp, HighContrastYellow, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Aumentar ampliação",
                    modifier = Modifier.size(30.dp)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ActionTileButton(
                icon = Icons.Default.Contrast,
                label = "Filtros",
                subLabel = uiState.activeFilter.shortName,
                isHighlighted = uiState.activeFilter != VisionFilter.NORMAL,
                contentDesc = "Filtros de cor e contraste. Atual: ${uiState.activeFilter.displayName}",
                onClick = onOpenFilters,
                modifier = Modifier.weight(1f)
            )

            ActionTileButton(
                icon = if (uiState.isFrozen) Icons.Default.PlayArrow else Icons.Default.PauseCircleFilled,
                label = if (uiState.isFrozen) "Ao Vivo" else "Congelar",
                subLabel = if (uiState.isFrozen) "Religar" else "Poupar",
                isHighlighted = uiState.isFrozen,
                contentDesc = if (uiState.isFrozen) "Descongelar e religar câmara" else "Congelar imagem e desligar câmara para poupar bateria",
                onClick = onToggleFreeze,
                modifier = Modifier.weight(1f)
            )

            ActionTileButton(
                icon = Icons.Default.RecordVoiceOver,
                label = "Ler Texto",
                subLabel = "Voz Offline",
                isHighlighted = false,
                contentDesc = "Capturar e ler texto em voz alta offline",
                onClick = onRunOcr,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun ActionTileButton(
    icon: ImageVector,
    label: String,
    subLabel: String,
    isHighlighted: Boolean,
    contentDesc: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = if (isHighlighted) HighContrastYellow else HighContrastSurface
    val fgColor = if (isHighlighted) HighContrastBlack else HighContrastWhite
    val subColor = if (isHighlighted) HighContrastBlack else HighContrastYellow

    Surface(
        onClick = onClick,
        color = bgColor,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(2.dp, HighContrastYellow),
        modifier = modifier
            .height(76.dp)
            .semantics {
                role = Role.Button
                contentDescription = contentDesc
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = fgColor,
                modifier = Modifier.size(28.dp)
            )
            Text(
                text = label,
                color = fgColor,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                maxLines = 1
            )
            Text(
                text = subLabel,
                color = subColor,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun FilterSelectionSheet(
    selectedFilter: VisionFilter,
    onSelectFilter: (VisionFilter) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Filtros de Daltonismo e Contraste",
            style = MaterialTheme.typography.titleLarge,
            color = HighContrastYellow
        )

        VisionFilter.entries.forEach { filter ->
            val isSelected = filter == selectedFilter
            Surface(
                onClick = { onSelectFilter(filter) },
                color = if (isSelected) HighContrastYellow else HighContrastBlack,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(2.dp, if (isSelected) HighContrastWhite else HighContrastYellow),
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics {
                        stateDescription = if (isSelected) "Selecionado" else "Não selecionado"
                    }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = filter.displayName,
                            color = if (isSelected) HighContrastBlack else HighContrastWhite,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = filter.description,
                            color = if (isSelected) HighContrastBlack else Color(0xFFCCCCCC),
                            fontSize = 14.sp
                        )
                    }
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = HighContrastBlack,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun OcrResultSheet(
    text: String,
    isSpeaking: Boolean,
    onToggleSpeak: () -> Unit,
    onCopyText: () -> Unit,
    onSaveText: () -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Texto Reconhecido (Offline)",
                style = MaterialTheme.typography.titleLarge,
                color = HighContrastYellow
            )
            IconButton(
                onClick = onClose,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Fechar janela de texto",
                    tint = HighContrastWhite,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 140.dp, max = 300.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(HighContrastBlack)
                .border(2.dp, HighContrastYellow, RoundedCornerShape(14.dp))
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = text,
                color = HighContrastWhite,
                fontSize = 22.sp,
                lineHeight = 32.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Button(
            onClick = onToggleSpeak,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isSpeaking) AlertRed else HighContrastYellow,
                contentColor = HighContrastBlack
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
        ) {
            Icon(
                imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                contentDescription = null,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = if (isSpeaking) "PARAR LEITURA" else "OUVIR EM VOZ ALTA",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 18.sp
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onCopyText,
                border = BorderStroke(2.dp, HighContrastYellow),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = HighContrastWhite),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = HighContrastYellow)
                Spacer(Modifier.width(8.dp))
                Text("Copiar", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onSaveText,
                border = BorderStroke(2.dp, HighContrastYellow),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = HighContrastWhite),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp)
            ) {
                Icon(Icons.Default.SaveAlt, contentDescription = null, tint = HighContrastYellow)
                Spacer(Modifier.width(8.dp))
                Text("Guardar TXT", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun PermissionRequiredScreen(onRequestPermission: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HighContrastBlack)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.CameraAlt,
            contentDescription = null,
            tint = HighContrastYellow,
            modifier = Modifier.size(80.dp)
        )
        Spacer(Modifier.height(20.dp))
        Text(
            text = "Acesso à Câmara Necessário",
            style = MaterialTheme.typography.titleLarge,
            color = HighContrastYellow,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = "A LupaAcessível funciona 100% offline. Nenhuma imagem ou texto sai do teu telemóvel.",
            style = MaterialTheme.typography.bodyLarge,
            color = HighContrastWhite,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onRequestPermission,
            colors = ButtonDefaults.buttonColors(
                containerColor = HighContrastYellow,
                contentColor = HighContrastBlack
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
        ) {
            Text(
                text = "PERMITIR CÂMARA",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 18.sp
            )
        }
    }
}
