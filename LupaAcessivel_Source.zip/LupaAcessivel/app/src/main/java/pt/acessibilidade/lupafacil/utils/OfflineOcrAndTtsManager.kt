package pt.acessibilidade.lupafacil.utils

import android.content.Context
import android.graphics.Bitmap
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

class OfflineOcrAndTtsManager(
    context: Context,
    private val onSpeakingStateChanged: (Boolean) -> Unit
) {
    // Modelo Latino/Português embutido diretamente no APK (zero rede)
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val ptPt = Locale("pt", "PT")
                val ptBr = Locale("pt", "BR")
                val result = when {
                    (tts?.isLanguageAvailable(ptPt) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= TextToSpeech.LANG_AVAILABLE -> {
                        tts?.setLanguage(ptPt)
                    }
                    (tts?.isLanguageAvailable(ptBr) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= TextToSpeech.LANG_AVAILABLE -> {
                        tts?.setLanguage(ptBr)
                    }
                    else -> {
                        tts?.setLanguage(Locale.getDefault())
                    }
                }
                isTtsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                        result != TextToSpeech.LANG_NOT_SUPPORTED

                tts?.setSpeechRate(0.95f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        onSpeakingStateChanged(true)
                    }

                    override fun onDone(utteranceId: String?) {
                        onSpeakingStateChanged(false)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        onSpeakingStateChanged(false)
                    }
                })
            }
        }
    }

    suspend fun recognizeTextFromBitmap(bitmap: Bitmap): Result<String> =
        suspendCancellableCoroutine { continuation ->
            try {
                val image = InputImage.fromBitmap(bitmap, 0)
                textRecognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        val cleaned = visionText.text.trim()
                        if (continuation.isActive) {
                            continuation.resume(Result.success(cleaned))
                        }
                    }
                    .addOnFailureListener { exception ->
                        if (continuation.isActive) {
                            continuation.resume(Result.failure(exception))
                        }
                    }
            } catch (e: Exception) {
                if (continuation.isActive) {
                    continuation.resume(Result.failure(e))
                }
            }
        }

    fun speak(text: String) {
        if (!isTtsReady || text.isBlank()) return
        stopSpeaking()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "LUPA_OCR_UTTERANCE")
    }

    fun stopSpeaking() {
        if (tts?.isSpeaking == true) {
            tts?.stop()
        }
        onSpeakingStateChanged(false)
    }

    fun release() {
        stopSpeaking()
        tts?.shutdown()
        tts = null
        textRecognizer.close()
    }
}
