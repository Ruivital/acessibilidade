# LupaAcessível (100% Offline • Sem Anúncios • Código Aberto)

Aplicação Android nativa desenvolvida em **Kotlin + Jetpack Compose + CameraX + Google ML Kit Text Recognition (Offline)**.

## Funcionalidades Principais
- **Privacidade Total:** Permissões `INTERNET` e `ACCESS_NETWORK_STATE` explicitamente bloqueadas no `AndroidManifest.xml`.
- **Poupança Extrema de Bateria:** Modo *Congelar* desliga fisicamente o sensor da câmara (`unbindAll()`) e o LED, mantendo a imagem em RAM com suporte a *pinch-to-zoom* e arrasto (*pan*).
- **Filtros em GPU (60 FPS):** Alto contraste (Branco/Preto, Amarelo/Preto, Invertido) e correção para daltonismo (Protanopia, Deuteranopia, Tritanopia).
- **OCR Local + Leitura em Voz Alta (TTS):** Modelo latino/português embutido no APK, com leitura de voz nativa e exportação local (Copiar ou Guardar TXT).
- **Ergonomia Física:** Botões de Volume (`+` / `-`) controlam o zoom; duplo toque no visor congela/descongela com feedback tátil.

## Compilação Automática no Linux Mint / Ubuntu
```bash
chmod +x compilar_linux_mint.sh
./compilar_linux_mint.sh
```
O ficheiro final será gerado na raiz como `LupaAcessivel.apk`.
